const btn = document.getElementById('learnMoreBtn');
const infoBlock = document.getElementById('infoBlock');

btn.addEventListener('click', () => {
  infoBlock.classList.toggle('show');
});
